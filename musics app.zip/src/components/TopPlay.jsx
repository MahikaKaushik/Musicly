const TopPlay = () => (
  <div>TopPlay</div>
);

export default TopPlay;
