const ArtistCard = () => {
  <div>ArtistCard</div>;
};

export default ArtistCard;
